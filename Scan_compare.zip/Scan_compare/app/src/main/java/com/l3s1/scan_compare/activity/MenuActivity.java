package com.l3s1.scan_compare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.l3s1.scan_compare.R;
import com.l3s1.scan_compare.util.Requester;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MenuActivity extends AppCompatActivity {
    private String scanOrigin = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //lier le fichier xml et java
        setContentView(R.layout.activity_menu);

        Requester.getInstance(this.getApplicationContext());

        final Button registerProductButton = findViewById(R.id.register_product);
        registerProductButton.setOnClickListener(v -> {
            scanOrigin = "register";
            startScan();
        });

        final Button searchProductButton = findViewById(R.id.search_product);
        searchProductButton.setOnClickListener(v -> {
            scanOrigin = "search";
            startScan();
        });

        final Button comparatorButton = findViewById(R.id.comparator_button);
        comparatorButton.setOnClickListener(v -> {
            scanOrigin = "comparator";
            startScan();
        });

        final Button historyButton = findViewById(R.id.history);
        historyButton.setOnClickListener(v -> {
            startHistory();
        });


        final Button helpButton = findViewById(R.id.help);
        helpButton.setOnClickListener(v -> {
            startHelp();
        });


    }

    private void startHistory() {
        Intent intent = new Intent(this, HistoryActivity.class);
        startActivity(intent);
    }


    private void startHelp() {
        Intent intent = new Intent(this, HelpActivity.class);
        startActivity(intent);
    }


    private void startScan() {
        new IntentIntegrator(this).initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Scanned: " + result.getContents(), Toast.LENGTH_LONG).show();

                Intent intent;
                switch (scanOrigin) {
                    case "search":
                        intent = new Intent(this, SearchActivity.class);
                        break;
                    case "comparator":
                        intent = new Intent(this,ComparatorActivity.class);
                        break;
                    case "register":
                        intent = new Intent(this, RegisterProductActivity.class);
                        break;
                    default:
                        intent = null;
                }
                scanOrigin = "";

                //Pour recuperer le code ean scanner
                intent.putExtra("codeEAN", result.getContents());
                startActivity(intent);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

}