package com.l3s1.scan_compare.help_activity;

import android.os.Bundle;

import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.l3s1.scan_compare.R;


public class HelpGuideActivity extends AppCompatActivity {

    private TextView presentationTextView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_guide);

        presentationTextView2 = (TextView) findViewById(R.id.pretextview2);
    }
}