package com.l3s1.scan_compare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.l3s1.scan_compare.R;
import com.l3s1.scan_compare.model.Category;
import com.l3s1.scan_compare.model.Product;
import com.l3s1.scan_compare.model.Shop;

import org.json.JSONException;
import org.json.JSONObject;

public class ModifyActivity extends AppCompatActivity {
    Shop shop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);

        Intent intent = getIntent();
        long shopId = intent.getLongExtra("shopId", -1);

        Product product = null;
        try {
            product = new Product(new JSONObject(getIntent().getStringExtra("product")));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        final TextView codeEanInput = findViewById(R.id.modify_codeEan_label);
        final TextView nameInput = findViewById(R.id.modify_name_label);
        final TextView brandInput = findViewById(R.id.modify_brand_label);
        final Spinner categorySpinner = findViewById(R.id.modify_category_spinner);


        if(shopId > 0) {
            Shop.getFromDB(shopId, object -> {
                try {
                    shop = new Shop(object);
                    //magasinInput.setText(shop.getName());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            });
        }

        Category.setAdapter(categorySpinner,this);
        codeEanInput.setText(product.getCodeEan());
        nameInput.setText(product.getName());
        brandInput.setText(product.getMarque());
        categorySpinner.setSelection(Category.getIndex(product.getCategory()));

        final Button modifyButton = findViewById(R.id.modify_valider_button);
        modifyButton.setOnClickListener(v -> {
            Product modifiedProduct = new Product(codeEanInput.getText().toString(), nameInput.getText().toString(), brandInput.getText().toString(), categorySpinner.getSelectedItem().toString());
            modifyProduct(modifiedProduct);

        });
        final Button addPriceButton = findViewById(R.id.modify_add_price_button);
        addPriceButton.setOnClickListener(v -> {
            Intent in = new Intent(this, AddPriceActivity.class);
            in.putExtra("codeEan", codeEanInput.getText().toString());
            in.putExtra("shopId", shopId);
            in.putExtra("product", getIntent().getStringExtra("product"));
            startActivity(in);
        });

    }
    private void modifyProduct(Product product) {
        product.modifyInDB();
        AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.setTitle("Produit Modifié");
        dialog.setMessage("Votre Produit a été modifié avec succes");
        dialog.setButton(AlertDialog.BUTTON_POSITIVE, "ok", (dialog1, which) -> {
            dialog1.dismiss();
            backToMenu(product.getCodeEan());
        });
        dialog.show();

    }
    private void backToMenu(String codeEAN) {
        Intent intent = new Intent(this, SearchActivity.class);
        intent.putExtra("codeEAN", codeEAN);
        startActivity(intent);
    }

}