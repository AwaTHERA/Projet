package com.l3s1.scan_compare.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.l3s1.scan_compare.R;
import com.l3s1.scan_compare.help_activity.HelpContextActivity;
import com.l3s1.scan_compare.help_activity.HelpDeveloppersActivity;
import com.l3s1.scan_compare.help_activity.HelpGuideActivity;

public class HelpActivity extends AppCompatActivity {

    Button bcontext = null;
    Button bdeveloppers = null;
    Button bguide = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        bcontext = findViewById(R.id.context_button);
        bdeveloppers = findViewById(R.id.developpers_button);
        bguide = findViewById(R.id.guide_button);

        bcontext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent help_context = new Intent(getApplicationContext(), HelpContextActivity.class);
                startActivity(help_context);
                finish();
            }
        });

        bdeveloppers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent help_developper = new Intent(getApplicationContext(), HelpDeveloppersActivity.class);
                startActivity(help_developper);
                finish();
            }
        });

        bguide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent help_guide = new Intent(getApplicationContext(), HelpGuideActivity.class);
                startActivity(help_guide);
                finish();
            }
        });


    }
}