package com.l3s1.scan_compare.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.l3s1.scan_compare.R;
import com.l3s1.scan_compare.model.Product;
import com.l3s1.scan_compare.model.Shop;

import org.json.JSONException;

public class AddPriceActivity extends AppCompatActivity {
    private Product product;
    private Shop shop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_price);

        String codeEan = getIntent().getStringExtra("codeEan");
        long shopId = getIntent().getLongExtra("shopId",-1);
        final TextView codeEanLabel = findViewById(R.id.add_price_code_ean_label);
        final TextView nameLabel = findViewById(R.id.add_price_name_label);
        final TextView magasinLabel = findViewById(R.id.add_price_magasin_label);
        final EditText datePicker = findViewById(R.id.add_price_date_picker);
        final EditText priceLabel = findViewById(R.id.add_price_prix_number);

        Product.getFromDB(codeEan, obj -> {
            try {
                product = new Product(obj);
                codeEanLabel.setText(product.getCodeEan());
                nameLabel.setText(product.getName());
            } catch(JSONException e) {
                e.printStackTrace();
            }
        });

        Shop.getFromDB(shopId, obj -> {
            try {
                shop = new Shop(obj);
                magasinLabel.setText(shop.getName());
            } catch(JSONException e) {
                e.printStackTrace();
            }
        });

        final Button button = findViewById(R.id.add_price_add_button);
        button.setOnClickListener(v -> {
            product.linkShop(shop, Double.parseDouble(priceLabel.getText().toString()), datePicker.getText().toString());

            Intent in = new Intent(this, AddPriceActivity.class);
            in.putExtra("codeEan", codeEan);
            in.putExtra("shopId",shopId);
            in.putExtra("product", getIntent().getStringExtra("product"));
            startActivity(in);
        });


    }
}