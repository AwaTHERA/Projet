package com.l3s1.scan_compare.model;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class Category {
    public static final String[] categories = new String[] {
            "Librairie",
            "Papetrie",
            "Alimentation"
    };
    public static void setAdapter(Spinner spinner , Context ctx){
        ArrayAdapter<String> adapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_dropdown_item, categories);
        spinner.setAdapter(adapter);
    }
    public static int getIndex(String category){
        for (int i=0;i<categories.length;i++){
            if(categories[i].equals(category))
                return i;
        }
        return -1;
    }
}
