package com.l3s1.scan_compare.model;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.l3s1.scan_compare.util.Requester;

import org.json.JSONException;
import org.json.JSONObject;

public class Product extends Model {
    private final String codeEan;
    private final String name;
    private final String marque;
    private final String category;

    public Product(String codeEan, String name, String marque, String category) {
        super("/product");
        this.codeEan = codeEan;
        this.marque = marque;
        this.name = name;
        this.category = category;
    }

    public Product(JSONObject object) throws JSONException {
        this(object.getString("ean_code"), object.getString("name"), object.getString("brand"), object.getString("category"));
    }

    public void saveToDB(Response.Listener<JSONObject> listener) {
        try {
            Requester.getInstance().addToRequestQueue(new JsonObjectRequest(Request.Method.POST, Requester.BASE_URL + "/product", this.toJson(), listener, Requester.printError()));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void getFromDB(String codeEan, Response.Listener<JSONObject> listener) {
        Requester.getInstance().addToRequestQueue(new JsonObjectRequest(Request.Method.GET, Requester.BASE_URL + "/product/" + codeEan, null, listener, Requester.printError()));

    }

    public void deleteFromDB() {
        Requester.getInstance().addToRequestQueue(new StringRequest(Request.Method.DELETE, Requester.BASE_URL + "/product/" + codeEan, null, Requester.printError()));
    }


    @Override
    public String toString() {
        return "Product{" +
                "codeEan='" + codeEan + '\'' +
                ", name='" + name + '\'' +
                ", marque='" + marque + '\'' +
                ", category='" + category + '\'' +
                '}';
    }

    public JSONObject toJson() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("ean_code", codeEan);
        obj.put("brand", marque);
        obj.put("name", name);
        obj.put("category", category);
        return obj;
    }

    public void linkShop(Shop shop, double price, String date) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("codeEan", codeEan);
            obj.put("price", price);
            obj.put("shopId", shop.getId());
            obj.put("date", date);
            Requester.getInstance().addToRequestQueue(new JsonObjectRequest(Request.Method.POST, Requester.BASE_URL + "/linkShop", obj, null, Requester.printError()));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public String getCodeEan() {
        return codeEan;
    }

    public String getName() {
        return name;
    }

    public String getMarque() {
        return marque;
    }

    public String getCategory() {
        return category;
    }
}
