package com.l3s1.scan_compare.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.l3s1.scan_compare.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class HistoryActivity extends AppCompatActivity {

	//On initialise les variables principales : listView qui affichera l'historique et data qui contiendra les produits de l'historique
    ListView listView = null;
    ImageButton details_button;
    //List<Product> data;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        listView = findViewById(R.id.history_list);

        //data = getHistory();
        //Se connecter à la BDD
        //Requête pour récupérer l'historique, stocker dans "data"
        //listView.setAdapter(new ProductHistoryAdapter(HistoryActivity.this, 0));


    }

    //definition méthode getHistory
/*
    class HistoryAdapter extends ArrayAdapter{

        public HistoryAdapter(@NonNull Context context, int resource) {
            super(context, resource);

        }

        @Override
        public int getCount() {
            return data.size();
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View design = getLayoutInflater().inflate(R.layout.history_row, null);

            //On récupère les différentes View de la ligne
            ImageView rowImage = design.findViewById(R.id.product_image);
            TextView rowName = design.findViewById(R.id.product_name);
            TextView rowEan = design.findViewById(R.id.product_ean);
            TextView rowDate = design.findViewById(R.id.product_date);

            //On affiche dans les View les informations du produit
            rowName.setText(data.get(position).getName());
            rowEan.setText(data.get(position).getEan());
            rowImage.setImageResource(R.drawable.logo);
            return design;
        }
    }*/
    

}