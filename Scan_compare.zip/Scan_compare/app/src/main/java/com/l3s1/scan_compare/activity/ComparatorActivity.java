package com.l3s1.scan_compare.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.l3s1.scan_compare.R;
import com.l3s1.scan_compare.model.Shop;
import com.l3s1.scan_compare.util.Requester;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

public class ComparatorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comparator);

        Requester.getInstance(this.getApplicationContext());

        Intent intent = getIntent();
        String codeEan = intent.getStringExtra("codeEAN");

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

        final TableLayout table = findViewById(R.id.comparator_table);
        final GraphView graph = findViewById(R.id.comparator_graph);
        graph.getGridLabelRenderer().setLabelFormatter(new DateAsXAxisLabelFormatter(this));
        graph.getGridLabelRenderer().setNumHorizontalLabels(3);
        //graph.getGridLabelRenderer().setHumanRounding(false);

        Requester.getInstance().addToRequestQueue(new JsonObjectRequest(Request.Method.GET, Requester.BASE_URL + "/product/" + codeEan + "/stats?sort=price", null, obj -> {
            try {
                JSONArray list = obj.getJSONArray("stats");
                LineGraphSeries<DataPoint> serie = new LineGraphSeries<>();

                for(int i = 0; i < list.length(); i++) {
                    JSONObject entry = list.getJSONObject(i);
                    TableRow row = new TableRow(this);
                    TextView magasinCell = new TextView(this);
                    magasinCell.setText(entry.getString("name"));
                    row.addView(magasinCell);
                    TextView dateCell = new TextView(this);
                    dateCell.setText(entry.getString("date"));
                    row.addView(dateCell);
                    TextView prixCell = new TextView(this);
                    prixCell.setText(entry.getString("price"));
                    row.addView(prixCell);

                    table.addView(row);
                }
                //graph.addSeries(serie);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, Requester.printError()));

        Requester.getInstance().addToRequestQueue(new JsonObjectRequest(Request.Method.GET, Requester.BASE_URL + "/product/" + codeEan + "/stats?sort=date", null, obj -> {
            try {
                JSONArray list = obj.getJSONArray("stats");
                LineGraphSeries<DataPoint> serie = new LineGraphSeries<>();

                for(int i = 0; i < list.length(); i++) {
                    JSONObject entry = list.getJSONObject(i);
                    Date date = dateFormat.parse(entry.getString("date").replace('T', ' ').replace("Z",""));
                    serie.appendData(new DataPoint(date, entry.getDouble("price")), true, 100);
                }
                graph.addSeries(serie);
            } catch (JSONException | ParseException e) {
                e.printStackTrace();
            }
        }, Requester.printError()));
    }

}