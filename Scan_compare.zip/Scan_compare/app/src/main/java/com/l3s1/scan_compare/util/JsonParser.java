package com.l3s1.scan_compare.util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Cette classe recupère la longitude et la latitude depuis le fichier Json
 */
public class JsonParser {
    //Attribut

    /**
     * Permet de retourner une Hashmap qui contient le nom et l'adresse du magasin
     *
     * @param object
     * @return @dataList
     */
    private HashMap<String, String> parseJsonObject(JSONObject object){
        //initialisation de dataList, qui contiendra le nom et l'adresse de chaque objet Json. Chaque objet correspond à un magasin
        HashMap<String, String> shopData = new HashMap<>();
        try {
            //On récupère le nom
            String name = object.getString( "name");
            //On récupère l'adresse
            String address = object.getString("vicinity");
            //latitude à partir de l'object
            //String latitude = object.getJSONObject("geometry").getJSONObject("location").getString("lat");
            //longitude à partir de l'object
            //String longitude = object.getJSONObject("geometry").getJSONObject("location").getString("lng");


            //Nous allons mettre tous les valeurs dans le hash map
            shopData.put("name", name);
            shopData.put("vicinity", address);
            //dataList.put("lat", latitude);
            //dataList.put("lng", longitude);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        //nous retournons le HashMap
        return shopData;
    }

    /**
     *Appelle la méthode parseJsonObject pour chaque élément du JSONArray passé en prammètre (donc chaque magasin)
     * @param jsonArray
     * @return @dataList une liste de HashMap
     */
    private List<HashMap<String, String>> parseJsonArray(JSONArray jsonArray){

        //Initialisation de la liste de hash map
        List<HashMap<String, String>> dataList = new ArrayList<>();
        for(int i = 0 ; i < jsonArray.length() ; i++){ //ERREURRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

            try {
                //initialisation de la HashMap
                HashMap<String, String> shopData = parseJsonObject((JSONObject) jsonArray.get(i));
                //Ajoute shopData ( = les infos du magasin) dans la liste de HashMap
                dataList.add(shopData);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        //On retourne la liste de HashMap
        return dataList;
    }


    /**
     * Renvoie une liste de HashMap contenant les informations de chaque magasins depuis le JSONObject
     * @param object
     * @return @jsonArray
     */
    public List<HashMap<String, String>> parseResult(JSONObject object){
        //Initialisation du JsonArray
        JSONArray jsonArray = null;
        //On récupère le résultat
        try {
            jsonArray = object.getJSONArray("results");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        //On retourne l'Array
        return parseJsonArray(jsonArray);
    }

}
