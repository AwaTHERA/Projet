const { Pool } = require('pg');
const express = require('express');

const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.json());


const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Mehiraaron1',
    port: 5432,
});

app.post('/product', (req, res) => {
    console.log('post product', req.body);
    pool.query('INSERT INTO public."product" (name,ean_code,brand,category) VALUES ($1,$2,$3,$4)', [req.body.name, req.body.ean_code, req.body.brand, req.body.category], (err, val) => {
        if (err) {
            console.log(err);
            res.send(err);
            return;
        }
        console.log(req.body);
        res.json({ message: 'ok' });

    });
})

app.get('/product/:codeEan', (req, res) => {
    pool.query('SELECT * FROM public."product" WHERE ean_code=\'' + req.params.codeEan + "'", (err, val) => {
        if (err) {
            console.log(err);
            res.send(err);
            return;
        }
        console.log(val.rows);
        res.json(val.rows[0]);

    });
});

app.delete('/product/:codeEan', (req, res) => {
    pool.query('DELETE FROM public."product" WHERE ean_code=\'' + req.params.codeEan + "'", (err, val) => {
        if (err) {
            console.log(err);
            res.send(err);
            return;
        }
        console.log("deleting");
        res.send("Le produit a bien etait supprimé");

    });
});
app.put('/product', (req, res) => {
    pool.query('UPDATE public."product" SET name=$1,brand=$3,category=$4 WHERE ean_code=$2; ', [req.body.name, req.body.ean_code, req.body.brand, req.body.category], (err, val) => {
        if (err) {
            console.log(err);
            res.send(err);
            return;
        }
        console.log("Produit modifié", req.body);
        res.json({ message: 'ok' });

    });
})

app.get('/product/:codeEan/stats', async (req, res) => {
    try {
        let sort = '';
        if (req.query.sort == 'date')
            sort = 'date';
        else
            sort = 'price';
    const val = await pool.query(`SELECT price,date,shop.name as name FROM public."details_product" JOIN public."shop" as shop ON shop_id=shop.id WHERE ean_code_product=$1 ORDER BY ${sort} LIMIT 5`, [req.params.codeEan]);
        console.log("Stats produit: ", val.rows);
        res.json({ stats: val.rows });
    } catch (err) {
        console.log(err);
        res.send(err);
    }
})


app.post('/shop', (req, res) => {
    const { name, street_number, street_name, city, postal_code } = req.body;
    pool.query('INSERT INTO  public."shop" (name,street_number,street_name,city,postal_code) VALUES ($1,$2,$3,$4,$5) RETURNING *', [name, Number(street_number), street_name, city, Number(postal_code)], (err, val) => {
        if (err) {
            console.log(err);
            res.send(err);
            return;
        }
        console.log(val.rows);
        res.json({ message: 'ok', id: Number(val.rows[0].id) });

    });
})

app.get('/shop/:id', (req, res) => {
    pool.query('SELECT * FROM public."shop" WHERE id=$1', [req.params.id], (err, val) => {
        if (err) {
            console.log(err);
            res.send(err);
            return;
        }
        console.log(val.rows);
        res.json(val.rows[0]);
    });
});

app.delete('/shop/:id', (req, res) => {
    pool.query('DELETE FROM public."shop" WHERE id=$1', [req.params.id], (err, val) => {
        if (err) {
            console.log(err);
            res.send(err);
            return;
        }
        console.log("deleting");
        res.send("Le magasin a bien etait supprimé");

    });
});
app.put('/shop', (req, res) => {
    const { name, id, street_number, street_name, city, postal_code } = req.body;
    pool.query('UPDATE public."shop" SET name=$1,street_number=$3,street_name=$4,city=$5,postal_code=$6 WHERE id=$2', [name, id, street_number, street_name, city, postal_code], (err, val) => {
        if (err) {
            console.log(err);
            res.send(err);
            return;
        }
        console.log("Magasin modifié", req.body);
        res.json({ message: 'ok' });

    });
})

app.post('/linkShop', async (req, res) => {
    const { codeEan, shopId, price, date } = req.body;
    const dateISO = new Date(date.replace('/', '-')).toISOString();
    try {
        await pool.query('INSERT INTO  public."details_product" (ean_code_product,price,date,shop_id) VALUES ($1,$2,$3,$4)', [codeEan, price, dateISO, shopId]);
        console.log(req.body);
        res.json({ message: 'ok' });
    } catch (e) {
        console.log(e);
        res.send(e);
    }
})


app.listen(3000, () => {
    console.log('listening on port 3000');
});