package com.l3s1.scan_compare.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.AsyncTaskLoader;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.l3s1.scan_compare.R;
import com.l3s1.scan_compare.model.Shop;
import com.l3s1.scan_compare.util.Requester;
import com.l3s1.scan_compare.util.JsonParser;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

class ShopView {
    TextView adresse;
    TextView nom;
    ImageButton shop;
    Shop model;

    public ShopView() {}

    public ShopView(TextView adresse, TextView nom, ImageButton shop) {
        this.adresse = adresse;
        this.nom = nom;
        this.shop = shop;
    }
}
public class ActivityShopResearch extends AppCompatActivity {
    //variables
    //Initialisation des Views dans le fichier xml
    ShopView[] shops;

    //latitude et longitude stockeront la position de l'utilisateur
    String latitude;
    String longitude;

    private Class<? extends Activity> origin;

    //Liste contenant les TextView affichant le nom de magasins
    ArrayList<TextView> nameViewList = new ArrayList<>(4);
    //Liste contenant les TextView affichant l'adresse des magasins
    ArrayList<TextView> addressViewList = new ArrayList<>(4);
    ArrayList<ImageButton> imageButtons = new ArrayList<>(4);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_research);

        //On récupère les coordonnées envoyées dans le Intent depuis l'activite precedente : LatitudeLongitude
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if(bundle != null){
            latitude = (String) bundle.get("latitude");
            longitude = (String) bundle.get("longitude");
            try {
                origin = (Class<? extends Activity>) Class.forName((String)bundle.get("origin"));
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        shops = new ShopView[4];
        for(int i = 0; i < 4; i++)
            shops[i] = new ShopView();

        //on lie les variables à leur équivalent xml
        shops[0].nom = findViewById(R.id.nom1);
        shops[1].nom = findViewById(R.id.nom2);
        shops[2].nom = findViewById(R.id.nom3);
        shops[3].nom = findViewById(R.id.nom4);
        shops[0].adresse = findViewById(R.id.adresse1);
        shops[1].adresse = findViewById(R.id.adresse2);
        shops[2].adresse = findViewById(R.id.adresse3);
        shops[3].adresse = findViewById(R.id.adresse4);
        shops[0].shop = findViewById(R.id.shop1);
        shops[1].shop = findViewById(R.id.shop2);
        shops[2].shop = findViewById(R.id.shop3);
        shops[3].shop = findViewById(R.id.shop4);


/*
        nameViewList.add(nom1);
        nameViewList.add(nom2);
        nameViewList.add(nom3);
        nameViewList.add(nom4);
        addressViewList.add(adresse1);
        addressViewList.add(adresse2);
        addressViewList.add(adresse3);
        addressViewList.add(adresse4);
        imageButtons.add(shop1);
        imageButtons.add(shop2);
        imageButtons.add(shop3);
        imageButtons.add(shop4);*/


        String url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=48.856279,%202.336619&rankby=distance&types=shop&sensor=true+&key=AIzaSyAtKoHTfmSEBf7uIDGOfopHVvDR2OPvOvA";
        //new PlaceTask().execute(url);
        Requester.getInstance().addToRequestQueue(new JsonObjectRequest(Request.Method.GET, url, null, obj -> {
            try {
                JSONArray list = obj.getJSONArray("results");
                for(int i = 0; i < list.length();i++) {
                    JSONObject sh = list.getJSONObject(i);
                    if (i < 4) {
                        String name = sh.getString("name");
                        shops[i].nom.setText(name);
                        shops[i].adresse.setText(sh.getString("vicinity"));
                        shops[i].model = new Shop(name, -1, 0, "", "", "");
                        shops[i].model.saveToDB();
                    }

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, Requester.printError()));


    }//fin onCreate

    private String downloadUrl(String stringUrl) throws IOException {

        URL url = new URL(stringUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.connect();

        InputStream stream = connection.getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        StringBuilder builder = new StringBuilder();

        String line = "";
        while ((line = reader.readLine()) != null) {
            builder.append(line);
        }

        String data = builder.toString();
        reader.close();

        return data;
    }//fin downloadUrl


    /**
     * L'objectif de cette classe est d'établir la connexion avec Google Maps et de télécharger le résultat de la requête. On a besoin de AsyncTask pour créer un thread secondaire.
     * En effet, Android renvoie une erreur lors d'une requête HTTPS dans le thread principal. Cf : https://www.androiddesignpatterns.com/2012/06/app-force-close-honeycomb-ics.html
     */
    private class PlaceTask extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            String data = null;
            //On essaie de télécharger le résultat de la requête Google Maps
            try {
                data = downloadUrl(urls[0]);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return(data);
        }

        /**
         * Une fois téléchargé le résultat de la requête on appel le parser
         * @param data
         */
        @Override
        protected void onPostExecute(String data){
            //Execute le Parser task
            new ParserTask().execute(data);
        }
    }//fin PlaceTask


    /**
     * Cette classe a pour objectif :
     * 1- Objet JsonParser pour traiter les données récupérées
     * 2- Obtenir une liste de HashMap qui contiennent pour chaque magasin son nom et son adresse
     * 3- Afficher ces informations à l'utilisateur pour qu'il puisse choisir le magasin d'enregistrement du produit
     */
    private class ParserTask extends AsyncTask<String, Integer, List<HashMap<String, String>>> {

        protected List<HashMap<String, String>> doInBackground(String... strings) {

            JsonParser jsonParser = new JsonParser();
            List<HashMap<String, String>> mapList = null;
            JSONObject object = null;

            try {
                //On transforme les "données brutes" téléchargées en un objet JSON qu'on pourra utiliser pour extraires les informations utiles
                object = new JSONObject(strings[0]);
                //On parse l'objet json
                mapList = jsonParser.parseResult(object);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return mapList;
        }


        @Override
        protected void onPostExecute(List<HashMap<String, String>> mapList) {

            for(int i = 0 ; i < mapList.size() && i < 4; i++){
                //Initialisation de la HashMap
                HashMap<String, String> hashMaps = mapList.get(i);

                //On récupère le nom
                String name = hashMaps.get("name");
                //On récupère l'adresse
                String address = hashMaps.get("vicinity");

                nameViewList.get(i).setText(name);
                addressViewList.get(i).setText(address);
            }
        }
    }//fin ParserTask

    public void selectShopOne(View view) {
        Intent shopSelection = new Intent(getApplicationContext(), origin);
        shopSelection.putExtra("shopId", shops[0].model.getId());
        startActivity(shopSelection);
        finish();
    }

    public void selectShopTwo(View view) {
        Intent shopSelection = new Intent(getApplicationContext(), origin);
        shopSelection.putExtra("shopId", shops[1].model.getId());
        startActivity(shopSelection);
        finish();
    }

    public void selectShopThree(View view) {
        Intent shopSelection = new Intent(getApplicationContext(), origin);
        shopSelection.putExtra("shopId", shops[2].model.getId());
        startActivity(shopSelection);
        finish();
    }

    public void selectShopFour(View view) {
        Intent shopSelection = new Intent(getApplicationContext(), origin);
        shopSelection.putExtra("shopId", shops[3].model.getId());
        startActivity(shopSelection);
        finish();
    }

}//fin ActivityShopResearch