package com.l3s1.scan_compare.util;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

public class Requester {
    private static Requester instance;
    private RequestQueue requestQueue;
    private static Context ctx;

    public static final String BASE_URL = "http://10.0.2.2:3000";

    private Requester(Context context) {
        ctx = context;
        requestQueue = getRequestQueue();
    }

    public static synchronized Requester getInstance(Context context) {
        if (instance == null) {
            instance = new Requester(context);
        }
        return instance;
    }

    public static synchronized Requester getInstance() {
        return instance;
    }

    public RequestQueue getRequestQueue() {
        if (requestQueue == null) {
            // getApplicationContext() is key, it keeps you from leaking the
            // Activity or BroadcastReceiver if someone passes one in.
            requestQueue = Volley.newRequestQueue(ctx.getApplicationContext());
        }
        return requestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req) {
        getRequestQueue().add(req);
    }



    public static Response.ErrorListener printError() {
        return error -> System.out.println(error.getMessage());
    }
}