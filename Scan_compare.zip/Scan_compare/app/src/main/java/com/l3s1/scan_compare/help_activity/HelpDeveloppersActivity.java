package com.l3s1.scan_compare.help_activity;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.l3s1.scan_compare.R;

public class HelpDeveloppersActivity extends AppCompatActivity {
    private TextView presentationTextView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_developpers);

        presentationTextView3 = (TextView) findViewById(R.id.pretextview2);
    }
}
