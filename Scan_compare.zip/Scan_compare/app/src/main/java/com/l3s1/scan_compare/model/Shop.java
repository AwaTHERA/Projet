package com.l3s1.scan_compare.model;

import android.graphics.Point;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.l3s1.scan_compare.util.Requester;

import org.json.JSONException;
import org.json.JSONObject;

public class Shop extends Model{
    private final String name;
    private long id;
    private final long streetNumber;
    private final String streetName;
    private final String city;
    private final String postalCode;

    private double latitude, longitude;

    public Shop(String name, long id, long streetNumber, String streetName, String city, String postalCode) {
        super("/shop");
        this.name = name;
        this.id = id;
        this.streetNumber = streetNumber;
        this.streetName = streetName;
        this.city = city;
        this.postalCode = postalCode;
    }

    public Shop(JSONObject obj) throws JSONException {
        this(obj.getString("name"),obj.getLong("id"),obj.getLong("street_number"),obj.getString("street_name"), obj.getString("city"), obj.getString("postal_code"));
    }

    public String getName() {
        return name;
    }

    public long getId() {
        return id;
    }

    public long getStreetNumber() {
        return streetNumber;
    }

    public String getStreetName() {
        return streetName;
    }

    public String getCity() {
        return city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    @Override
    public String toString() {
        return "Shop{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", streetNumber=" + streetNumber +
                ", streetName='" + streetName + '\'' +
                ", city='" + city + '\'' +
                ", postalCode='" + postalCode + '\'' +
                '}';
    }
    public JSONObject toJson() throws JSONException {
        JSONObject obj =  new JSONObject();
        obj.put("name", name);
        obj.put("id", id);
        obj.put("street_number", streetNumber);
        obj.put("street_name",streetName);
        obj.put("city",city);
        obj.put("postal_code",postalCode);
        return obj;
    }

    public void saveToDB() {
        try {
            Requester.getInstance().addToRequestQueue(new JsonObjectRequest(Request.Method.POST, Requester.BASE_URL + url, this.toJson(), res -> {
                try {
                    this.id = res.getLong("id");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }, Requester.printError()));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void getFromDB(long id, Response.Listener<JSONObject> listener) {
        Requester.getInstance().addToRequestQueue(new JsonObjectRequest(Request.Method.GET, Requester.BASE_URL + "/shop/" + id, null, listener, Requester.printError()));
    }

    public void deleteFromDB() {
        Requester.getInstance().addToRequestQueue(new StringRequest(Request.Method.DELETE, Requester.BASE_URL + "/shop/" + id, null, Requester.printError()));
    }
}
