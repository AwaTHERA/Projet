package com.l3s1.scan_compare.activity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.l3s1.scan_compare.R;
import com.l3s1.scan_compare.model.Category;
import com.l3s1.scan_compare.model.Product;
import com.l3s1.scan_compare.model.Shop;
import com.l3s1.scan_compare.util.Requester;

import org.json.JSONException;

public class RegisterProductActivity extends AppCompatActivity {
    Shop shop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_product);

        Requester.getInstance(this.getApplicationContext());

        Intent intent = getIntent();
        String codeEan = "123456789";// = intent.getStringExtra("codeEAN");
        long shopId = intent.getLongExtra("shopId", -1);
        final EditText codeEanInput = findViewById(R.id.code_ean);
        codeEanInput.setText(codeEan);
        final EditText nameInput = findViewById(R.id.nom_input);
        final EditText priceInput = findViewById(R.id.prix_input);
        final EditText magasinInput = findViewById(R.id.register_magasin_input);
        final ImageButton mapView = findViewById(R.id.mapView);
        final Button registerProductButton = findViewById(R.id.valider_register);
        final EditText datePicker = findViewById(R.id.register_date_picker);
        final Spinner spinnerCategory = findViewById(R.id.spinner_category);
        final EditText marqueInput = findViewById(R.id.marque_input);

        Category.setAdapter(spinnerCategory,this);

        if(shopId > 0) {
            Shop.getFromDB(shopId, object -> {
                try {
                    shop = new Shop(object);
                    magasinInput.setText(shop.getName());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            });
        }

        mapView.setOnClickListener(v -> {
            Intent in = new Intent(this, ActivityShopResearch.class);
            in.putExtra("origin", this.getClass().getName());
            startActivity(in);
        });

        registerProductButton.setOnClickListener(v -> {
            String price = priceInput.getText().toString();
            if (price.isEmpty()) {
                priceInput.setError("Le prix est invalide ");
                return;
            }
            Product product = new Product(codeEanInput.getText().toString(), nameInput.getText().toString(), marqueInput.getText().toString(), spinnerCategory.getSelectedItem().toString());
            product.saveToDB(response -> {
                product.linkShop(shop, Double.parseDouble(price), datePicker.getText().toString());
                showMessage(product);
            });
        });
    }

    private void showMessage(Product product) {
        AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.setTitle("Produit Créé");
        dialog.setMessage("Votre Produit a été créé avec succes");
        dialog.setButton(AlertDialog.BUTTON_POSITIVE, "ok", (dialog1, which) -> {
            dialog1.dismiss();
            backToMenu();
        });
        dialog.show();

    }
    private void backToMenu() {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }
}
