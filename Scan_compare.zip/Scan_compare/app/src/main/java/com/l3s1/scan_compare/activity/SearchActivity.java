package com.l3s1.scan_compare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.l3s1.scan_compare.R;
import com.l3s1.scan_compare.model.Product;
import com.l3s1.scan_compare.util.Requester;
import com.l3s1.scan_compare.activity.ComparatorActivity;

import org.json.JSONException;

public class SearchActivity extends AppCompatActivity {

    private Product product;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_product);

        Requester.getInstance(this.getApplicationContext());

        //String codeEan = getIntent().getStringExtra("codeEAN");
        String codeEan = "123456789";
        /*
        Product product = new Product(codeEan,"pate","Panzani","Alimentation");
        try {
            JSONObject object = product.toJson();
            DBinterface.sendData("/product", object);

        }catch(JSONException e) {
            e.printStackTrace();
        }*/

        final TextView codeEanLabel = findViewById(R.id.search_codeEan_label);
        final TextView nameLabel = findViewById(R.id.search_name_label);
        final TextView brandLabel = findViewById(R.id.search_brand_label);
        final TextView categoryLabel = findViewById(R.id.search_category_label);


        Product.getFromDB(codeEan, object -> {
            try {
                product = new Product(object);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            codeEanLabel.setText(product.getCodeEan());
            nameLabel.setText(product.getName());
            brandLabel.setText(product.getMarque());
            categoryLabel.setText(product.getCategory());

        });

        final Button deleteButton = findViewById(R.id.search_delete_button);
        deleteButton.setOnClickListener(v -> deleteProduct());

        final Button modifyButton = findViewById(R.id.search_modify_button);
        modifyButton.setOnClickListener(v -> modifyProduct());



        findViewById(R.id.search_comparator_button).setOnClickListener(v -> {
            Intent in = new Intent(this, ComparatorActivity.class);
            in.putExtra("codeEAN", codeEan);
            startActivity(in);
        });

    }

    private void deleteProduct() {
        product.deleteFromDB();
        AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.setTitle("Produit Supprimé");
        dialog.setMessage("Votre Produit a été supprimé avec succes");
        dialog.setButton(AlertDialog.BUTTON_POSITIVE, "ok", (dialog1, which) -> {
            dialog1.dismiss();
            backToMenu();
        });
        dialog.show();

    }

    private void backToMenu() {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }

    private void modifyProduct() {
        Intent intent = new Intent(this, ModifyActivity.class);
        try {
            intent.putExtra("product", product.toJson().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        startActivity(intent);
    }

    private void addPrice() {
        Intent intent = new Intent(this, AddPriceActivity.class);
        intent.putExtra("codeEan", product.getCodeEan());
        startActivity(intent);
    }


}