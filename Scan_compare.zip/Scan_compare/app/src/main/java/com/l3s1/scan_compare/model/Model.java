package com.l3s1.scan_compare.model;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.l3s1.scan_compare.util.Requester;

import org.json.JSONException;
import org.json.JSONObject;
import org.xml.sax.HandlerBase;

public abstract class Model {
    protected String url;

    public Model(String url) {
        this.url = url;
    }

    protected abstract JSONObject toJson() throws JSONException;

    public void saveToDB() {
        try {
            Requester.getInstance().addToRequestQueue(new JsonObjectRequest(Request.Method.POST, Requester.BASE_URL + url, this.toJson(), null, Requester.printError()));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public abstract void deleteFromDB();

    public void modifyInDB() {
        try {
            Requester.getInstance().addToRequestQueue(new JsonObjectRequest(Request.Method.PUT, Requester.BASE_URL + url, this.toJson(), null, Requester.printError()));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
