
public class DiskManagerTests {
	
	public static void main(String [] args) {
		//CreateFile(123444);
	}
	void TestEcriturePage(int fileIdx) {
		
	}
}
