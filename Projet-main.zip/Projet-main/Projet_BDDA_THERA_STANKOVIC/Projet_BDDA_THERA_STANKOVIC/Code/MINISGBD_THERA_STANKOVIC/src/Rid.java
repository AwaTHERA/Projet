

	public class Rid {
		
		private PageId pageId;
		private int slotIdx ;

		
		public Rid(PageId pageId, int i) {
			// TODO Auto-generated constructor stub
		}

		

	}

